// You are building a simple shopping list app. You have the items name in an array. Write a program that uses a for loop to print all the items in the shopping list array.

let shoppingList = [
  "Pen",
  "Papper",
  "Candy",
  "Soda",
  "Keyboard",
  "Screen Protector",
];

for (let i = 0; i < shoppingList.length; i++) {
  console.log(shoppingList[i]);
}
